#!/bin/sh
cp check/styles.css output/
java -cp lib/program.jar:. GenerateurSite 
