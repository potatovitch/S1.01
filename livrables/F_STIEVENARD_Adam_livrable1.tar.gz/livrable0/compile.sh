#!/bin/sh
javac -cp lib/program.jar:. Generateur.java
