#!/bin/sh
javac -cp lib/program.jar:. GenerateurProduit.java