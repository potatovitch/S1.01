class GenerateurProduit extends Program{
    String rechercherValeur(String nom, String produit){
        int indice = 0, nb_boucle = 0;
        String val = "";
        boolean bool = false;
        while(!bool && (indice + length(nom))<= length(produit)){
            if (equals(substring(produit,indice,indice+length(nom)) , nom)){
                bool = true;
                nb_boucle = indice;
                while (!equals(substring(produit,nb_boucle,nb_boucle +1),"\n") && nb_boucle <= length(produit)){
                    nb_boucle +=1;
                }
                val = substring(produit,indice+length(nom)+3,nb_boucle);
            }else{
                indice+=1;
            }
        }
        return val;
    }

    String genererProduit(String fichier){
        final String TITRE = rechercherValeur("nom", fichier);
        final String DATE = rechercherValeur("date", fichier);
        final String ENTREPRISE = rechercherValeur("entreprise", fichier);
        final String PRIX = rechercherValeur("prix", fichier);
        final String DESC = rechercherValeur("description", fichier);

        final char N = '\n';

        String chaine = 
            "<!DOCTYPE html>" + N +
            "<html lang=\"fr\">" + N + 
            "  <head>" + N + 
            "    <title>" + TITRE + "</title>" + N + 
            "    <meta charset=\"utf-8\">" + N +  
            "  </head>" + N + 
            "  <body>" + N + 
            "    <h1>" + TITRE + " (" + ENTREPRISE + ')' + "</h1>" + N +
            "    <h2>" + PRIX + " (Sortie en " + DATE + ')'+ "</h2>" + N +
            "    <p>" + N +
            DESC + N +
            "    </p>" + N +
            "  </body>" + N + 
            "</html>";

        return chaine;
    }

    void algorithm(){
        //for in range 5 pour le nb d'arg
        String FILENAME = argument(0);
        if (!fileExist(FILENAME)){
            error("le fichier n'existe pas");
        }else{
            println(genererProduit(fileAsString(FILENAME)));
        }
    }
}