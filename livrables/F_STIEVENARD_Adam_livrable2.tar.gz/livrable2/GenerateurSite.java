class GenerateurSite extends Program{
    final char N = '\n';

    String genererIndex(){
        String chaine =
                        "<!DOCTYPE html>" + N +
                        "<html lang=\"fr\">" + N +
                        "  <head>" + N +
                        "    <title>Ordinateurs mythiques</title>" + N +
                        "    <meta charset=\"utf-8\">" + N +
                        "    <link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">" + N +
                        "  </head>" + N +
                        "  <body>" + N +
                        "    <header>" + N +
                        "      <h1>Ordinateurs mythiques</h1>" + N +
                        "    </header>" + N +
                        "    <nav>" + N +
                        "      <ul>" + N +
                        "        <li><a href=\"index.html\">Accueil</a></li>" + N +
                        "        <li><a href=\"produit1.html\">Produit 1</a></li>" + N +
                        "        <li><a href=\"produit2.html\">Produit 2</a></li>" + N +
                        "        <li><a href=\"produit3.html\">Produit 3</a></li>" + N +
                        "        <li><a href=\"produit4.html\">Produit 4</a></li>" + N +
                        "        <li><a href=\"produit5.html\">Produit 5</a></li>" + N +
                        "      </ul>" + N +
                        "    </nav>" + N +
                        "    <main>" + N +
                        "      <section>" + N +
                        "        <h2>Tout ce que vous avez toujours voulu savoir sur les vieux ordis sans jamais avoir osé le demander !</h2>" + N +
                        "          <p>" + N +
                        "Bienvenue dans le musée virtuel d'ordinateurs mythiques de l'histoire de l'informatique. Vous trouverez ici des éléments sur quelques machines qui ont marqué l'histoire de l'informatique que cela soit par leurs caractéristiques techniques ou l'impact commercial qu'elles ont eu et qui ont contribué au développement du secteur informatique." + N +
                        "          </p>" + N +
                        "      </section>" + N +
                        "    </main>" + N +
                        "  </body>" + N +
                        "</html>";

        return chaine;
    }


    String rechercherValeur(String chaine, String cle) {
        String valeur = "";
        int indice = 0;
        while (indice < length(chaine) && indice+length(cle) < length(chaine) && 
               !equals(cle, substring(chaine, indice, indice+length(cle)))) {
            indice = indice + 1;
        }
        if (indice < length(chaine)-length(cle)) {
            int indiceRetourLigne = indice;
            while (indiceRetourLigne < length(chaine) && charAt(chaine, indiceRetourLigne) != N) {
                indiceRetourLigne = indiceRetourLigne + 1;
            }
            valeur = substring(chaine, indice+length(cle), indiceRetourLigne);
        }
        return valeur;
    }

    String genererSiteProduit(String filename){
        final String CONTENU     = fileAsString(filename);
        final String NOM         = rechercherValeur(CONTENU, "nom : ");
        final String DATE        = rechercherValeur(CONTENU, "date : ");
        final String ENTREPRISE  = rechercherValeur(CONTENU, "entreprise : ");
        final String PRIX        = rechercherValeur(CONTENU, "prix : ");
        final String DESCRIPTION = rechercherValeur(CONTENU, "description : ");

        String chaine =
                        "<!DOCTYPE html>" + N +
                        "<html lang=\"fr\">" + N +
                        "  <head>" + N +
                        "    <title>Ordinateurs mythiques</title>" + N +
                        "    <meta charset=\"utf-8\">" + N +
                        "    <link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">" + N +
                        "  </head>" + N +
                        "  <body>" + N +
                        "    <header>" + N +
                        "      <h1>Ordinateurs mythiques</h1>" + N +
                        "    </header>" + N +
                        "    <nav>" + N +
                        "      <ul>" + N +
                        "        <li><a href=\"index.html\">Accueil</a></li>" + N +
                        "        <li><a href=\"produit1.html\">Produit 1</a></li>" + N +
                        "        <li><a href=\"produit2.html\">Produit 2</a></li>" + N +
                        "        <li><a href=\"produit3.html\">Produit 3</a></li>" + N +
                        "        <li><a href=\"produit4.html\">Produit 4</a></li>" + N +
                        "        <li><a href=\"produit5.html\">Produit 5</a></li>" + N +
                        "      </ul>" + N +
                        "    </nav>" + N +
                        "    <main>" + N +
                        "      <section>" + N +
                        "        <h2>" + NOM + " (" + ENTREPRISE + ")</h2>" + N +
                        "        <h3>" + PRIX + " (Sortie en " + DATE + ")</h3>" + N +
                        "        <p>" + N +
                        DESCRIPTION + N +
                        "        </p>" + N +
                        "      </section>" + N +
                        "    </main>" + N +
                        "  </body>" + N +
                        "</html>";
                        
        return chaine;
    }
    
    void algorithm(){
        stringAsFile("output/index.html", genererIndex());
        stringAsFile("output/produit1.html", genererSiteProduit("data/produit1.txt"));
        stringAsFile("output/produit2.html", genererSiteProduit("data/produit2.txt"));
        stringAsFile("output/produit3.html", genererSiteProduit("data/produit3.txt"));
        stringAsFile("output/produit4.html", genererSiteProduit("data/produit4.txt"));
        stringAsFile("output/produit4.html", genererSiteProduit("data/produit5.txt"));
    }
}