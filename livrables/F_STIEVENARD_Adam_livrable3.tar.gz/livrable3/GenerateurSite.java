class GenerateurSite extends Program{
    final int IDX_NOM = 0;
    final int IDX_DATE = 1;
    final int IDX_ENTREPRISE = 2;
    final int IDX_PRIX = 3;
    final int IDX_DESCRIPTION = 4; 
    final int ELEMENTNUMBER = 5; 
    final char N ='\n';

    void algorithm(){
        genererProduit();
    }

    void genererProduit(){
        String[][] content = chargerProduits("data/", "produit");
        String result = getIndexPageCore(getBaseStart(content, 0)) + getBaseEnd() + N;
        stringAsFile("output/index.html", result);

        for (int indice = 0; indice < length(content, 2);indice ++) {
            String resultProduct = getBaseStart(content, indice);
            resultProduct = getPageCore(resultProduct, content, indice) + getBaseEnd();
            stringAsFile("output/produit"+(indice + 1)+".html", resultProduct);
        }
    }

    String[][] chargerProduits(String repertoire, String prefixe) {
        String[] fileNameArray = getAllFilesFromDirectory(repertoire);    
        int fileToStore = length(fileNameArray);
        String[][] content = new String[ELEMENTNUMBER][fileToStore]; 
        
        String[] lKEY = new String[]{"nom : ", "date : ", "entreprise : ", "prix : ", "description : "};

        for (int indice = 1; indice <= fileToStore; indice++) {
            if(fileExist(repertoire+prefixe+indice+".txt")){
                final String TEXT = fileAsString(repertoire+prefixe+indice+".txt");
                for(int keyIndex = 0; keyIndex < ELEMENTNUMBER; keyIndex++){
                    content[keyIndex][indice - 1] = rechercherValeur(TEXT, lKEY[keyIndex]);
                }
            }else{
                final String MESSAGE = "generer-produit.sh génère une page HTML à partir d'un fichier texte structuré.\n" +
                            "En supposant qu'il existe un fichier produit1.txt dans le répertoire data qui respecte le format\n" +
                            "la commande suivante générera le fichier HTML correspondant dans output/produit1.html\n" +
                            "Syntaxe : ./generer-produit.sh produit1";
                error(MESSAGE);
            }
        }
        return content;
    }

    String getBaseStart(String[][] contentOfFile, int indice){
        int fileNameHtml = indice + 1;
        String result = 
                 "<!DOCTYPE html>" + N+
                 "<html lang=\"fr\">" + N +
                 "  <head>" + N +
                 "    <title>Ordinateurs mythiques</title>" + N +
                 "    <meta charset=\"utf-8\">" + N +
                 "    <link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\">" + N +
                 "  </head>" + N +
                 "  <body>" + N +
                 "    <header>" + N +
                 "      <h1>Ordinateurs mythiques</h1>" + N +
                 "    </header>" + N +
                 "    <nav>" + N +
                 "      <ul>" + N+
                 "        <li><a href=\"index.html\">Accueil</a></li>" + N +
                 "        <li><a href=\"produit"+fileNameHtml+".html\">"+contentOfFile[IDX_NOM][indice]+"</a></li>" + N;

        int diff = length(contentOfFile, 2) - indice - 1;
        int tempNb = 0;
        if(diff > 0){
            tempNb = indice + 2;
            result += "        <li><a href=\"produit"+tempNb+".html\">"+contentOfFile[IDX_NOM][indice + 1 ]+"</a></li>" + N;

            if(diff > 1){
                tempNb = indice + 3;
                result +=  "        <li><a href=\"produit"+tempNb+".html\">"+contentOfFile[IDX_NOM][indice + 2 ]+"</a></li>" + N;

                if(diff > 2){
                    tempNb = indice + 4;
                    result +=  "        <li><a href=\"produit"+tempNb+".html\">"+contentOfFile[IDX_NOM][indice + 3 ]+"</a></li>" + N;

                    if(diff > 3){
                        tempNb = indice + 5;
                        result +=  "        <li><a href=\"produit"+tempNb+".html\">"+contentOfFile[IDX_NOM][indice + 4 ]+"</a></li>" + N;
                    }
                }
            }
        }
        result +=  "      </ul>" + N+ "    </nav>" + N +  "    <main>" + N + "      <section>" + N;   
        return result;
    }

    String getIndexPageCore(String input){                          
        return input +  "        <h2>Tout ce que vous avez toujours voulu savoir sur les vieux ordis sans jamais avoir osé le demander !</h2>" + N +
                        "          <p>" + N +
                        "Bienvenue dans le musée virtuel d'ordinateurs mythiques de l'histoire de l'informatique. Vous trouverez ici des éléments sur quelques machines qui ont marqué l'histoire de l'informatique que cela soit par leurs caractéristiques techniques ou l'impact commercial qu'elles ont eu et qui ont contribué au développement du secteur informatique." + N +
                        "          </p>" + N;
    }

    String getPageCore(String input, String[][] contentOfFile, int indice){
        return input +  "        <h2>"+contentOfFile[IDX_NOM][indice]+" ("+contentOfFile[IDX_ENTREPRISE][indice]+")</h2>" + N +
                        "        <h3>"+contentOfFile[IDX_PRIX][indice]+" (Sortie en "+contentOfFile[IDX_DATE][indice]+")</h3>" + N + 
                        "        <p>" + N + contentOfFile[IDX_DESCRIPTION][indice] + N +"        </p>" + N;
    }

    String getBaseEnd(){
        return  "      </section>" + N + "    </main>" + N + "  </body>" +N + "</html>"; 
    }

    String rechercherValeur(String chaine, String cle) {
        String valeur = "";
        int indice = 0;
        while (indice < length(chaine) && indice+length(cle) < length(chaine) && 
               !equals(cle, substring(chaine, indice, indice+length(cle)))) {
            indice += 1;
        }
        if (indice < length(chaine)-length(cle)) {
            int indiceRetourLigne = indice;
            while (indiceRetourLigne < length(chaine) && charAt(chaine, indiceRetourLigne) != N) {
                indiceRetourLigne += 1;
            }
            valeur = substring(chaine, indice+length(cle), indiceRetourLigne);
        }
        return valeur;
    } 
}