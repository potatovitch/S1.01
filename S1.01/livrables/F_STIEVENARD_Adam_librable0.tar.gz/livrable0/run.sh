#!/bin/sh
java -cp lib/program.jar:. Generateur > output/index.html